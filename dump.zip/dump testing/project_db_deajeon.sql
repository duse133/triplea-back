-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: project_db
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `deajeon`
--

DROP TABLE IF EXISTS `deajeon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deajeon` (
  `attraction_name` varchar(255) NOT NULL,
  `district_classification` varchar(50) DEFAULT NULL,
  `map_name_address` varchar(255) DEFAULT NULL,
  `number_address` varchar(255) DEFAULT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `area` double DEFAULT NULL,
  `public_convenience_info` varchar(255) DEFAULT NULL,
  `accommodation_info` varchar(255) DEFAULT NULL,
  `exercise_entertainment_info` varchar(255) DEFAULT NULL,
  `recreational_cultural_info` varchar(255) DEFAULT NULL,
  `hospitality_info` varchar(255) DEFAULT NULL,
  `support_info` varchar(255) DEFAULT NULL,
  `introduction` text,
  `agency_phone_number` varchar(20) DEFAULT NULL,
  `provider_organization` varchar(100) DEFAULT NULL,
  `management_organization` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`attraction_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deajeon`
--

LOCK TABLES `deajeon` WRITE;
/*!40000 ALTER TABLE `deajeon` DISABLE KEYS */;
INSERT INTO `deajeon` VALUES ('계족산황톳길','관광지','대전광역시 대덕구 장동로 59','대전광역시 대덕구 와동 2-1',36.40406651,127.4297932,54000,'Y','N','Y','Y','N','Y','Y','042-623-9909','Y','대전광역시'),('대전둘레산길','관광단지','대전광역시 중구 보문산공원로 440','대전광역시 중구 대사동 195-2',36.30879672,127.4231236,159000,'Y','N','Y','Y','N','Y','Y','042-270-5583','N','대전광역시'),('대전문화예술단지','관광단지','대전광역시 서구 둔산대로 169','대전광역시 서구 만년동 396',36.366496,127.3880154,33150,'Y','N','Y','Y','N','Y','Y','042-270-8333','N','대전광역시'),('대청호반','관광지','대전광역시 대덕구 대청로 607','대전광역시 대덕구 미호동 57',36.47362538,127.4735679,72800,'Y','N','Y','Y','N','Y','Y','042-930-7240','Y','대전광역시'),('동춘당','관광지','대전광역시 대덕구 동춘당로 80','대전광역시 대덕구 송촌동 192',36.36537889,127.4412933,4492,'Y','N','Y','Y','N','Y','Y','042-607-6575','N','대전광역시'),('뿌리공원','관광지','대전광역시 중구 뿌리공원로 79(침산동)','대전광역시 중구 침산동 364',36.28538043,127.3883,125000,'관광안내소+수유실','효문화마을관리원','국궁장','성씨조형물+캠핑장+한국족보박물관 등','','','전국유일의 효 테마공원으로서 자신의 뿌리를 되찾을 수 있는 성씨별 조형물과 수변무대, 전망대, 산림욕장 등 다양한 시설이 갖추어진 체험학습의 산 교육장  *수용인원:제한없음','042-288-8301','대전광역시 중구청','대전광역시 중구'),('아쿠아리움','관광지','대전광역시 중구 보문산공원로 469(대사동)','대전광역시 중구 대사동 198-14',36.31005741,127.4209439,18708,'휠체어+유모차대여소+보관소+수유실+고객지원센터','','','아쿠아리움+체험동물원','','','전쟁에 대비해 지하방공호로 활용하던 대전 도심의 천연동굴을 변화시킨 수족관으로 국내최초이자 최대인 담수어 아쿠아리움  *수용인원:제한없음','042-226-2100','㈜신라애니멀그룹','대전광역시 중구'),('엑스포과학공원','관광지','대전광역시 유성구 대덕대로 480','대전광역시 유성구 도룡동 3-1',36.37662561,127.3871992,130000,'Y','N','Y','Y','N','Y','Y','042-250-1111','Y','대전광역시'),('오월드','관광지','대전광역시 중구 사정공원로 70(사정동)','대전광역시 중구 사정동 142',36.28749924,127.3985039,682830,'유모차대여소+수유실+의무실+고객지원센터+물품보관소','','버드랜드+조이랜드+플라워랜드+시즌놀이시설','행복쉼터','','','주랜드 + 플라워랜드 + 조이랜드”를 복합적으로 구성하여 온가족이 함께 즐길 수 있는 테마공원 *수용인원:제한없음','042-580-4820','대전도시공사','대전광역시 중구'),('유성온천','관광지','대전광역시 유성구 계룡로60','대전광역시 유성구 봉명동 574',36.3547298,127.3375865,273970,'Y','N','Y','Y','N','Y','Y','042-611-2114','N','대전광역시'),('으능정이문화의거리','관광지','대전광역시 중구 중앙로 170','대전광역시 중구 은행동 45-10',36.32934665,127.428337,630.8,'Y','N','Y','Y','N','Y','Y','042-252-7100','N','대전광역시'),('장태산휴양림','관광지','대전광역시 서구 장안로 461','대전광역시 서구 장안동 259',36.21596913,127.3412778,815855,'Y','N','Y','Y','N','Y','Y','042-270-7883','Y','대전광역시'),('한밭수목원','관광지','대전광역시 서구 둔산대로 169','대전광역시 서구 만년동 396',36.36646857,127.3880154,387000,'Y','N','Y','Y','N','Y','Y','042-270-8464','Y','대전광역시');
/*!40000 ALTER TABLE `deajeon` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-26 13:26:09
