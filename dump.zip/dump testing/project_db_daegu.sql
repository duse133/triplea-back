-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: project_db
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `daegu`
--

DROP TABLE IF EXISTS `daegu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daegu` (
  `attraction_name` varchar(255) NOT NULL,
  `district_classification` varchar(50) DEFAULT NULL,
  `map_name_address` varchar(255) DEFAULT NULL,
  `number_address` varchar(255) DEFAULT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `area` double DEFAULT NULL,
  `public_convenience_info` varchar(255) DEFAULT NULL,
  `accommodation_info` varchar(255) DEFAULT NULL,
  `exercise_entertainment_info` varchar(255) DEFAULT NULL,
  `recreational_cultural_info` varchar(255) DEFAULT NULL,
  `hospitality_info` varchar(255) DEFAULT NULL,
  `support_info` varchar(255) DEFAULT NULL,
  `introduction` text,
  `agency_phone_number` varchar(20) DEFAULT NULL,
  `provider_organization` varchar(100) DEFAULT NULL,
  `management_organization` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`attraction_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daegu`
--

LOCK TABLES `daegu` WRITE;
/*!40000 ALTER TABLE `daegu` DISABLE KEYS */;
INSERT INTO `daegu` VALUES ('경북대학교 캠퍼스','관광지','대구광역시 북구 대학로80','대구광역시 북구 산격동 1370-1',35.88909849,128.6143217,1317639,'화장실+주차장+휴게시설','','','','','','대구광역시 북구 8경사진찍기좋은명소','053-665-2344','대구광역시 북구청','대구광역시 북구'),('구암서원','관광지','대구광역시 북구 연암공원로17길 20','대구광역시 북구 산격동 산79-1',35.89881592,128.5989989,65000,'화장실+주차장+관광안내시설+휴게시설','','','','','','대구광역시 북구 8경사진찍기좋은명소','053-665-2344','대구광역시 북구청','대구광역시 북구'),('금호강하중도','관광지','','대구광역시 북구 노곡동 673',35.90019471,128.5595886,223000,'화장실+주차장','','','','','','대구광역시 북구 8경사진찍기좋은명소','053-665-2344','대구광역시 북구청','대구광역시 북구'),('김수환 추기경 사랑과 나눔 공원','관광지','대구광역시 군위군 군위읍 군위금성로 270','대구광역시 군위군 군위읍 용대리 424',36.232449,128.599613,32128,'공원','','','기념관+경당+추기경생가+십자가의 길+평화의 숲+추모정원+중앙광장+잔디광장+옹기가마','','','김수환 추기경의 사랑과 나눔 정신의 계승,확산을 위한 정신문화 공간','054-380-6064','대구광역시 군위군청','대구광역시 군위군'),('꽃보라동산','관광지','','대구광역시 북구 산격동 1500-6',35.88935018,128.601059,10000,'화장실+벤치+벚꽃길','','','','','','대구광역시 북구 8경사진찍기좋은명소','053-665-2344','대구광역시 북구청','대구광역시 북구'),('달성토성마을','관광지','대구광역시 서구 국채보상로 83길 21 (비산동) 일대','대구광역시 서구 비산동 404-5',35.87331563,128.5753765,45000,'행복한 날뫼골 공방','','','채비천연염색공방+전양순자수박물관+마을도서관 햇빛따라+퍼팩토리소극장','달성토성마을 다락방','','집안에 있는 화분을 골목으로 꺼내놓으며 시작된 골목정원','053-663-2181','대구광역시 서구청','대구광역시 서구'),('사라온 이야기 마을','관광지','대구광역시 군위군 군위읍 동서길 49','대구광역시 군위군 군위읍 서부리 44-1',36.236155,128.567733,8140,'관리사무소+주차장','','','야외쉼터+환희문(정문)+적라촌+적라청+적라골','매표소','','선조들이 살아온 역사와 문화를 적라촌, 적라청, 적라골 3가지 테마로 나누어 재현','054-380-7216','대구광역시 군위군청','대구광역시 군위군'),('운암지수변공원','관광지','','대구광역시 북구 구암동 349',35.93241418,128.5674979,17962,'화장실+데크로드+분수대+생활공원+유아숲체험원','','','','','','대구광역시 북구 8경사진찍기좋은명소','053-665-2344','대구광역시 북구청','대구광역시 북구'),('침산정','관광지','대구광역시 북구 침산남로9길 118','대구광역시 북구 침산동 1168-3',35.897221,128.5848591,291080,'화장실+주차장+휴게시설','','','','','','대구광역시 북구 8경사진찍기좋은명소','053-665-2344','대구광역시 북구청','대구광역시 북구'),('팔공산 하늘정원','관광지','','대구광역시 군위군 부계면 동산리 산 74-18',36.023813,128.696761,6000,'정자+탐방로','','정자+탐방로','정자+탐방로','','','오도암, 비로봉, 동봉, 서봉 등 팔공산의 봉우리들을 자유롭게 다닐 수 있는 오름길','054-380-7943','대구광역시 군위군청','대구광역시 군위군'),('팔달대교 야경','관광지','','대구광역시 북구 팔달동 524-4',35.89629048,128.5491628,10000,'조명시설','','','','','','대구광역시 북구 8경사진찍기좋은명소','053-665-2344','대구광역시 북구청','대구광역시 북구'),('함지공원','관광지','대구광역시 북구 동암로38길 9','대구광역시 북구 구암동 775-6',35.9424608,128.570482,44385,'화장실+주차장+음악공원시설+물놀이시설+휴게시설','','','','','','대구광역시 북구 8경사진찍기좋은명소','053-665-2344','대구광역시 북구청','대구광역시 북구');
/*!40000 ALTER TABLE `daegu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-26 13:26:10
